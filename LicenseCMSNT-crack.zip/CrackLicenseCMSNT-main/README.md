<br/>
<div align="center">
  
# CrackLicenseCMSNT
</div>


--------------------------------------

### Sử dụng

1. Tải về và giải ném vào thư mục gốc trong host của bạn cùng với source code SHOPCLONE của CMSNT
2. Cài cronjob vào url {domain}/{VERSION}.php để tự động crack sau khi update

### Ghi chú
* Thay trường {VERSION} bằng SHOPCLONE5 hoặc SHOPCLONE6 tùy thuộc vào phiên bản của bạn

